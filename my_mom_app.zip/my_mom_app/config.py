import json
import logging
from settings import CONFIG_FILE, SHOW_INTERVAL, HIDE_INTERVAL

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s] %(levelname)s:%(name)s: %(message)s"
)
logger = logging.getLogger(__name__)

class ConfigError(Exception):
    """Кастомное исключение для ошибок конфигурации."""
    pass

class Config:
    """
    Класс для работы с настройками пользователя:
    - язык
    - громкость вывода (не используется, но заготовка)
    - интервалы показа/скрытия аватара
    """
    def __init__(self):
        # Значения по умолчанию
        self.language      = "ru_RU"
        self.volume        = 0.8
        self.show_interval = SHOW_INTERVAL
        self.hide_interval = HIDE_INTERVAL

        # загружаем сохранённые настройки
        self.load()

    def load(self):
        """Загрузить настройки из JSON-файла, если он существует."""
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            self.language      = data.get("language",      self.language)
            self.volume        = float(data.get("volume",   self.volume))
            self.show_interval = float(data.get("show_interval", self.show_interval))
            self.hide_interval = float(data.get("hide_interval", self.hide_interval))
            logger.info("Конфигурация загружена из %s", CONFIG_FILE)
        except FileNotFoundError:
            logger.warning("Файл конфигурации не найден: %s. Используются значения по умолчанию.", CONFIG_FILE)
        except (json.JSONDecodeError, ValueError) as e:
            logger.error("Ошибка чтения конфигурации: %s", e)
            raise ConfigError("Неверный формат config.json")

    def save(self):
        """Сохранить текущие настройки в JSON-файл."""
        data = {
            "language"      : self.language,
            "volume"        : self.volume,
            "show_interval" : self.show_interval,
            "hide_interval" : self.hide_interval
        }
        try:
            with open(CONFIG_FILE, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=4)
            logger.info("Конфигурация сохранена в %s", CONFIG_FILE)
        except Exception as e:
            logger.error("Не удалось сохранить конфигурацию: %s", e)
            raise ConfigError("Ошибка при сохранении config.json")

    def reset_to_defaults(self):
        """Сбросить настройки к значениям по умолчанию."""
        self.language      = "ru_RU"
        self.volume        = 0.8
        self.show_interval = SHOW_INTERVAL
        self.hide_interval = HIDE_INTERVAL
        logger.info("Настройки сброшены к значениям по умолчанию")

    def update_show_interval(self, value: float):
        """Обновить интервал показа аватара."""
        if value < 0:
            raise ConfigError("show_interval не может быть отрицательным")
        self.show_interval = value

    def update_hide_interval(self, value: float):
        """Обновить интервал скрытия аватара."""
        if value < 0:
            raise ConfigError("hide_interval не может быть отрицательным")
        self.hide_interval = value

    def update_language(self, lang_code: str):
        """Обновить язык и проверить на корректность."""
        if not isinstance(lang_code, str) or len(lang_code) < 2:
            raise ConfigError("Неверный код языка")
        self.language = lang_code

    def __repr__(self):
        """Отладочное представление объекта Config."""
        return (
            f"<Config language={self.language!r}, volume={self.volume}, "
            f"show_interval={self.show_interval}, hide_interval={self.hide_interval}>"
        )

# Точка входа для самостоятельного тестирования
if __name__ == "__main__":
    cfg = Config()
    print(cfg)
    cfg.update_show_interval(10)
    cfg.update_hide_interval(2.5)
    cfg.save()
    cfg.reset_to_defaults()
    print(cfg)
    cfg.save()
